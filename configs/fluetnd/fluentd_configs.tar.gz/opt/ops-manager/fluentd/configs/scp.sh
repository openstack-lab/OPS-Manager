#!/bin/bash
### Version 0.0.1 

SSH_SCP ()
{
	TD_AGENT="/etc/init.d/td-agent"
	TODAY=`date "+%Y%m%d_%H%M%S"`
	SCP="scp -o StrictHostKeyChecking=no"
	SSH="ssh -o StrictHostKeyChecking=no"

	echo -e "\n[-- $1 --]"
	echo  "backup td-agent.conf -> ${TD_AGENT_CONFIG}_${TODAY}"	
	${SSH} $1 "cp -p ${TD_AGENT_CONFIG}{,.bak_${TODAY}}" >/dev/null 2>&1
	echo -e "-----\nsend ${OPS_MANAGER_PATH}${2}${TD_AGENT_CONFIG}"
	${SCP} ${OPS_MANAGER_PATH}/${2}${TD_AGENT_CONFIG} $1:$TD  >/dev/null 2>&1 
	echo -e "-----\ntd-agent restart"
	${SSH} $1 "${TD_AGENT} restart  ; ${TD_AGENT} status" 
	exit
}

export OPS_MANAGER_PATH="/opt/ops-manager/fluentd/configs"
export TD_AGENT_CONFIG="/etc/td-agent/td-agent.conf" 
export -f SSH_SCP

READ_LINE ()
{
	numLine=0
	if [ $3 = "CONT_LXC"  ]; then
		grep $1 $2 | while read line
		do
			numLine=$((numLine + 1)) 
			echo ${line}  | awk '{print $2}' | xargs -I % bash -c "SSH_SCP % ${LINE}"
   		#	SSH_SCP ${SED_HOST} ${line} 
		done
	elif [ $3 = "OTHER" ]; then
		cat $2 | while read line
		do
			numLine=$((numLine + 1)) 
   			echo ${line} | xargs -I % bash -c "SSH_SCP % $1"
		done
	else
		exit 1
	fi	
}

case $1 in
	"all" )
		for NODE in cinder_api_container cinder_scheduler_container galera_container glance_container horizon_container keystone_container memcached_container neutron_agents_container neutron_server_container nova_api_metadata_container nova_api_os_compute_container nova_cert_container nova_conductor_container nova_console_container nova_scheduler_container rabbit_mq_container; 
		do
			if [ -e ${OPS_MANAGER_PATH}/${NODE}${TD_AGENT_CONFIG} ]; then
				READ_LINE ${NODE} "/etc/hosts" CONT_LXC
			else
				echo "${OPS_MANAGER_PATH}/${1}${TD_AGENT_CONFIG} is not found."
			fi
		done
		for NODE in cinder_volume controller_LXC_HOST nova_compute elasticsearch; 
		do
			READ_LINE ${NODE} ${OPS_MANAGER_PATH}/${NODE}.txt OTHER
		done
		;;
	* )
		for i in `seq 1 ${#}`;
		do
			if [ -e ${OPS_MANAGER_PATH}/${1}${TD_AGENT_CONFIG} ]; then
				if [ ${1} = "cinder_volume" -o ${1} = "controller_LXC_HOST" -o ${1} = "nova_compute" -o ${1} = "elasticsearch" ];then
					READ_LINE ${1} ${OPS_MANAGER_PATH}/${1}.txt OTHER
				else
					READ_LINE ${1} "/etc/hosts" CONT_LXC
				fi
			else
				echo -e "${OPS_MANAGER_PATH}/${1}${TD_AGENT_CONFIG} is not found.\nThis argument(${1}) is skipped ."
			fi
    			shift        
		done
esac
exit
