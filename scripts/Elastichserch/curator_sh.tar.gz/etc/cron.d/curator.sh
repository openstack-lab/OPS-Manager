#!/bin/bash

LOGGER="/usr/bin/logger"
CURATOR="/usr/local/bin/curator"

HOST="localhost"
PREFIX="logstash"
CLOSE_DAY="5"
DELETE_DAY="10"
LOG_TAG="CURATOR"


${LOGGER} -i -t ${LOG_TAG} "index close"
${CURATOR} --host ${HOST} close indices --prefix ${PREFIX} --older-than ${CLOSE_DAY} --time-unit days --timestring %Y.%m.%d | ${LOGGER} -i -t ${LOG_TAG}


${LOGGER} -i -t ${LOG_TAG} "index delete"
${CURATOR} --host ${HOST} delete indices --prefix ${PREFIX} --older-than ${DELETE_DAY} --time-unit days --timestring %Y.%m.%d  | ${LOGGER} -i -t ${LOG_TAG}

exit
