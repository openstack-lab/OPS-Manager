#!/bin/bash

###################################################
# Please execute this script in the controller #1 #
###################################################

MONITOR_USER_PASSWORD="OpenStack_Zabbix_User_Password"
MONITOR_USER_NAME="zabbix"
TENANT_NAME="zabbix_monitoring"

MANAGEMENT_IF="br-mgmt"
PARSE_STRING="."
#TARGET="publicURL"
TARGET=${2}

HA_PROXY_IP=`ip addr show ${MANAGEMENT_IF} | grep -o 'inet [0-9]\+\.[0-9]\+\.[0-9]\+\.[0-9]\+' | grep -o [0-9].*`
RESULT=`curl -s http://${HA_PROXY_IP}:5000/v2.0/tokens -X POST -H "Content-Type: application/json" -d '{"auth":{"tenantName": "'"${TENANT_NAME}"'", "passwordCredentials":{"username":"'"${MONITOR_USER_NAME}"'","password":"'"${MONITOR_USER_PASSWORD}"'"}}}'`
TOKEN=`echo ${RESULT} | jq -r ".access.token.id"`
TENANT_ID=`echo ${RESULT} | jq -r ".access.token.tenant.id"`

## $1 Compornent Name $2 publicURL or internalURL

function GET_URL () 
{
	echo ${RESULT} |  jq -r '.access.serviceCatalog[] | select(.name == "'"${1}"'").endpoints[0].'"${TARGET}"''
}

function API_EXECUTION_RESULT ()
{
#	curl -s -H "X-Auth-Token: ${TOKEN}" "${1}" |jq "${2}"
	curl -L -H "X-Auth-Token: ${TOKEN}" "${1}" -o '/dev/null' -w '%{http_code}\n' -s
}

case ${1} in
	"nova" )
		WORD="flavors"
		;;
	"novav21" )
		WORD="${TENANT_ID}/flavors"
		;;
	"neutron" )
		WORD="/v2.0/networks"
		;;
	"cinderv2" )
		WORD="volumes"
		;;
	"cinder" )
		WORD="volumes"
		;;
	"keystone" )
		WORD="tenants"
		;;
	"glance" )
		WORD="v1/images"
		;;
	* )
		exit 1 
		;;
	esac
API_EXECUTION_RESULT "`GET_URL ${1}`/${WORD}" "${PARSE_STRING}"
exit 0
